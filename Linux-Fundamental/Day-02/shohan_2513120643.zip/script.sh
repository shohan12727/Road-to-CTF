#!/bin/bash

echo "Current User: $(whoami)"

if [ "$EUID" -ne 0 ]; then
echo "Switching to root user"
sudo bash "$0"
exit
fi

if [ "$EUID" -eq 0 ];then
echo "I am in root currently"
else
echo "Normal User"
fi

echo "Creating confidential.txt file.."
touch confidential.txt

echo "Setting Permissions"
chmod 600 confidential.txt

echo "Extracting last 50 logs using journalctl"
journalctl -n 50 > confidential.txt

echo "Display contents of confidential.txt file's information"
cat confidential.txt